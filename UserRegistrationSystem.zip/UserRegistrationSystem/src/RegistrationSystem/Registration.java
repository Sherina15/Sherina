package RegistrationSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Registration extends javax.swing.JFrame {
             
    public Registration() 
    {
        initComponents(); 
        try {
            Connection();
        } catch (SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    
    private static final String dbName = "user_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try{
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            if (con != null){
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        right_Panel = new javax.swing.JPanel();
        registration_Label = new javax.swing.JLabel();
        name_Label = new javax.swing.JLabel();
        name_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_TextField = new javax.swing.JPasswordField();
        email_Label = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        register_Button = new javax.swing.JButton();
        accountLogin_Button = new javax.swing.JLabel();
        login_Button = new javax.swing.JButton();
        contact_TextField = new javax.swing.JTextField();
        contactNumber_Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("REGISTRATION");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(0, 0, 51));
        main_Panel.setForeground(new java.awt.Color(153, 153, 153));
        main_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        right_Panel.setBackground(new java.awt.Color(255, 255, 255));

        registration_Label.setBackground(new java.awt.Color(0, 0, 51));
        registration_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        registration_Label.setText("REGISTRATION");

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setText("Name");

        name_TextField.setForeground(new java.awt.Color(153, 153, 153));
        name_TextField.setText("Enter Name");
        name_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                name_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                name_TextFieldFocusLost(evt);
            }
        });

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");

        username_TextField.setForeground(new java.awt.Color(153, 153, 153));
        username_TextField.setText("Enter Username");
        username_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusLost(evt);
            }
        });

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password ");

        password_TextField.setForeground(new java.awt.Color(153, 153, 153));
        password_TextField.setText("Enter Password");
        password_TextField.setEchoChar('\u0000');
        password_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                password_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                password_TextFieldFocusLost(evt);
            }
        });

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");

        email_TextField.setForeground(new java.awt.Color(153, 153, 153));
        email_TextField.setText("Enter Email");
        email_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusLost(evt);
            }
        });

        register_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        register_Button.setText("Register");
        register_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                register_ButtonActionPerformed(evt);
            }
        });

        accountLogin_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accountLogin_Button.setForeground(new java.awt.Color(0, 0, 51));
        accountLogin_Button.setText("Already have a account?");

        login_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        login_Button.setForeground(new java.awt.Color(102, 0, 0));
        login_Button.setText("Login");
        login_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_ButtonActionPerformed(evt);
            }
        });

        contact_TextField.setForeground(new java.awt.Color(153, 153, 153));
        contact_TextField.setText("Enter Contact Number ");

        contactNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        contactNumber_Label.setText("Contact No.");

        javax.swing.GroupLayout right_PanelLayout = new javax.swing.GroupLayout(right_Panel);
        right_Panel.setLayout(right_PanelLayout);
        right_PanelLayout.setHorizontalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(104, 104, 104)
                .addComponent(accountLogin_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(login_Button)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, right_PanelLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, right_PanelLayout.createSequentialGroup()
                        .addComponent(registration_Label)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, right_PanelLayout.createSequentialGroup()
                        .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(register_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(right_PanelLayout.createSequentialGroup()
                                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(username_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(name_Label)
                                    .addComponent(email_Label)
                                    .addComponent(password_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(contactNumber_Label))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(contact_TextField)
                                    .addComponent(name_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                    .addComponent(email_TextField)
                                    .addComponent(password_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                    .addComponent(username_TextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))))
                        .addGap(56, 56, 56))))
        );
        right_PanelLayout.setVerticalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(right_PanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(registration_Label)
                .addGap(28, 28, 28)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(contact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(contactNumber_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(register_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addGroup(right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(accountLogin_Button)
                    .addComponent(login_Button))
                .addGap(42, 42, 42))
        );

        main_Panel.add(right_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 0, 400, 500));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void login_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_ButtonActionPerformed
        Login frameLogin = new Login();
        frameLogin.setVisible(true);
        dispose();
    }//GEN-LAST:event_login_ButtonActionPerformed

    private void name_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_TextFieldFocusGained
        if (name_TextField.getText().equals("Enter Name"))
        {
            name_TextField.setText("");
            name_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_name_TextFieldFocusGained

    private void name_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_TextFieldFocusLost
        if (name_TextField.getText().equals(""))
        {
            name_TextField.setText("Enter Name");
            name_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_name_TextFieldFocusLost

    private void username_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusGained
        if (username_TextField.getText().equals("Enter Username"))
        {
            username_TextField.setText("");
            username_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_username_TextFieldFocusGained

    private void username_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusLost
        if (username_TextField.getText().equals(""))
        {
            username_TextField.setText("Enter Username");
            username_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_username_TextFieldFocusLost

    private void password_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_TextFieldFocusGained
        if (String.valueOf(password_TextField.getPassword()).equals("Enter Password"))
        {
           password_TextField.setText("");
           password_TextField.setForeground(Color.BLACK);
           password_TextField.setEchoChar('•');
        }
    }//GEN-LAST:event_password_TextFieldFocusGained

    private void password_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_TextFieldFocusLost
        if (password_TextField.getPassword().length<1)
        {
            password_TextField.setEchoChar('\u0000');
            password_TextField.setText("Enter Password");
            password_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_password_TextFieldFocusLost

    private void email_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusGained
        if (email_TextField.getText().equals("Enter Email"))
        {
            email_TextField.setText("");
            email_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_email_TextFieldFocusGained

    private void email_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusLost
        if (email_TextField.getText().equals(""))
        {
            email_TextField.setText("Enter Email");
            email_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_email_TextFieldFocusLost

    private void register_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_register_ButtonActionPerformed
       String acc_name,acc_username,acc_password,acc_email,acc_ContactNumber;
       
        if ("".equals(name_TextField.getText()))
        {
           JOptionPane.showMessageDialog(new JFrame(), "Name is required","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if ("".equals(username_TextField.getText()))
        {
           JOptionPane.showMessageDialog(new JFrame(), "Username is required","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if ("".equals(password_TextField.getText()))
        {
           JOptionPane.showMessageDialog(new JFrame(), "Password is required","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if ("".equals(email_TextField.getText()))
        {
           JOptionPane.showMessageDialog(new JFrame(), "Email is required","Error",JOptionPane.ERROR_MESSAGE);
        }
        else if ("".equals(email_TextField.getText()))
        {
            JOptionPane.showMessageDialog(new JFrame(), "Contact number is required","Error",JOptionPane.ERROR_MESSAGE);   
        }
        else
        {
           acc_name = name_TextField.getText();
           acc_username = username_TextField.getText();
           acc_password = password_TextField.getText();
           acc_email = email_TextField.getText();
           acc_ContactNumber = contact_TextField.getText();
 
           String queryRegister = "INSERT INTO userprofile(Name,Username,Password,Email,Contact Number)" + "VALUES"
                                   + "('"+acc_name+"','"+acc_username+"','"+acc_password+"','"+acc_email+"','"+acc_ContactNumber+"')";
           try 
           {
               st.execute(queryRegister);
           } catch (SQLException ex) 
           {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
           }
               JOptionPane.showMessageDialog(new JFrame(), "Data register successfully.",
                                            "Data Success",JOptionPane.INFORMATION_MESSAGE);
               name_TextField.setText("");
               username_TextField.setText("");
               password_TextField.setText("");
               email_TextField.setText("");
               
               
        }
    }//GEN-LAST:event_register_ButtonActionPerformed

    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel accountLogin_Button;
    private javax.swing.JLabel contactNumber_Label;
    private javax.swing.JTextField contact_TextField;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JButton login_Button;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JLabel name_Label;
    private javax.swing.JTextField name_TextField;
    private javax.swing.JLabel password_Label;
    private javax.swing.JPasswordField password_TextField;
    private javax.swing.JButton register_Button;
    private javax.swing.JLabel registration_Label;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
