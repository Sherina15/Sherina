//package RegistrationSystem;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//public class Database_Connection {
//    static Connection con;    
//    
//    public static Connection getConnection(){
//        
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/registration_database","root","");
//        }
//        catch (Exception e){
//           System.out.println(""+ e); 
//        }
//        return con;
//    }
//}
//
//           String acc_name,acc_username,acc_password,acc_email,acc_address,query;
//            String SUrl, SUser,SPass;
//            SUrl = "jdbc:mysql://localhost:3306/registration_database";
//            SUser = "root";
//            SPass = "";
//            
//          
//            try {
//
//               Class.forName("com.mysql.cj.jdbc.Driver");
//               Connection con = DriverManager.getConnection(SUrl,SUser,SPass);
//               Statement st = con.createStatement();
//               
//               if ("".equals(name_TextField.getText())){
//                  JOptionPane.showMessageDialog(new JFrame(), "Full Name is require","Error",JOptionPane.ERROR_MESSAGE);
//               }
//               else if("".equals(username_TextField.getText())){
//                  JOptionPane.showMessageDialog(new JFrame(), "Username is require","Error",JOptionPane.ERROR_MESSAGE);
//               }
//               else if ("".equals(jPasswordField1.getText())){
//                  JOptionPane.showMessageDialog(new JFrame(), "password is require","Error",JOptionPane.ERROR_MESSAGE);
//               }
//               else if ("".equals(email_TextField.getText())){
//                  JOptionPane.showMessageDialog(new JFrame(), "Email is require","Error",JOptionPane.ERROR_MESSAGE);
//               }
//               else if ("".equals(address_TextField.getText())){
//                  JOptionPane.showMessageDialog(new JFrame(), "Address is require","Error",JOptionPane.ERROR_MESSAGE);
//               }
//               else{
//                acc_name = name_TextField.getText();
//                acc_username = username_TextField.getText();
//                acc_password = jPasswordField1.getText();
//                acc_email = email_TextField.getText();
//                acc_address = address_TextField.getText();
//                
//                query = "INSERT INTO registration_database (name,username,password,email,address)" + "VALUES ('"+acc_name+"','"+acc_username+"','"+acc_password+"','"+acc_email+"','"+acc_address+"')";
//                st.execute(query);
//                name_TextField.setText("");
//                username_TextField.setText("");
//                jPasswordField1.setText("");
//                email_TextField.setText("");
//                address_TextField.setText("");
//                JOptionPane.showMessageDialog(null, "New account has been created successfully");
//
//               }
//               
//            }
//            catch (Exception e)
//            {
//               System.out.println("Error" + e.getMessage());
//                
//            }

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

